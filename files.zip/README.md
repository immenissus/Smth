```markdown
# FluxVideo — AI Video Maker (Prototype)

This repo contains a minimal frontend and backend to demo a SaaS AI Video Maker with Stripe Checkout.

## What's included
- public/index.html — modern landing page & checkout buttons
- server.js — Express server that creates Stripe Checkout sessions and receives webhooks
- package.json — dependencies & scripts

## Setup (local)
1. Clone the repo and add these files (or create an initial commit if the repo is empty).
2. Install:
   npm install

3. Create `.env` from `.env.example` and fill in:
   - STRIPE_SECRET_KEY — your Stripe secret key
   - STRIPE_WEBHOOK_SECRET — stripe webhook signing secret
   - BASE_URL — e.g. http://localhost:3000

4. Set up price IDs in your Stripe Dashboard (the server expects the `priceId` passed from the client to match a real price ID).

5. Run locally:
   npm run dev
   Open http://localhost:3000

## Webhook testing
- Use the Stripe CLI or ngrok to expose your local server and configure your webhook signing secret.
  Example with Stripe CLI:
  stripe listen --forward-to localhost:3000/webhook

## Notes & next steps
- Implement user onboarding and linking Stripe customer -> local user.
- Replace placeholder price IDs in the UI with real Stripe price IDs.
- Harden webhook handling and persist events (database).
- Add rendering worker(s) for video generation and task queue (e.g. BullMQ / Redis).

Enjoy! If you want, I can:
- push these files into a new branch (once the repo has an initial commit),
- or create a ZIP you can download,
- or expand backend (DB, user auth, job queue).
```