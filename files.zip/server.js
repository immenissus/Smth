'use strict';

/**
 * Minimal Express server for FluxVideo
 * - Serves ./public
 * - POST /create-checkout-session  { priceId } -> returns { url }
 * - POST /webhook (raw body) -> handles Stripe webhook events
 *
 * IMPORTANT:
 * - Set STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET in environment.
 * - Price IDs must be created in your Stripe Dashboard and used as values (e.g. price_pro_monthly).
 */

const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || '');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Create a Checkout Session and return session.url
app.post('/create-checkout-session', async (req, res) => {
  try {
    const { priceId } = req.body;
    if (!priceId) return res.status(400).json({ error: 'Missing priceId' });

    // Create a checkout session (subscription mode for SaaS)
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${BASE_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${BASE_URL}/cancel`
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error('Checkout session error', err);
    res.status(500).json({ error: err.message });
  }
});

// Stripe webhook endpoint — uses raw body
app.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!webhookSecret) {
    console.warn('No webhook secret configured; cannot verify stripe events');
    return res.status(400).send('Webhook secret not configured');
  }

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    console.error('⚠️  Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle the event
  switch (event.type) {
    case 'checkout.session.completed':
      const session = event.data.object;
      console.log('Checkout completed for session:', session.id);
      // TODO: fulfill the purchase (create user, grant subscription, etc.)
      break;
    case 'invoice.paid':
      // handle subscription invoice payment
      break;
    case 'customer.subscription.deleted':
      // subscription canceled
      break;
    default:
      console.log(`Unhandled event type ${event.type}`);
  }

  res.json({ received: true });
});

// Fallback — serve index
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server listening on ${PORT}`);
});